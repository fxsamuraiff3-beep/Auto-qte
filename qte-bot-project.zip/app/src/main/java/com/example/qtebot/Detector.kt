package com.example.qtebot

import java.nio.ByteBuffer
import kotlin.math.abs

/** What one captured frame says about the QTE bar. Positions are relative to the bar's left edge. */
class BarState {
    var valid = false      // is the dark-red bar visible at all?
    var zl = -1            // white zone left
    var zr = -1            // white zone right
    var mx = -1.0          // marker centre (between its two red edges)
}

object Detector {
    /**
     * Reads a thin band through the middle of the bar straight out of the RGBA frame buffer.
     * Same thresholds as the PC script (tested on a real recording).
     */
    fun detect(
        buf: ByteBuffer, rowStride: Int, pixStride: Int,
        x0: Int, x1: Int, yc: Int, half: Int, out: BarState
    ) {
        val rows = 2 * half + 1
        val y0 = yc - half
        val width = x1 - x0

        var darkCols = 0
        var wCols = 0; var wMin = Int.MAX_VALUE; var wMax = -1
        var rCols = 0; var rMin = Int.MAX_VALUE; var rMax = -1

        for (x in x0 until x1) {
            var wc = 0; var rc = 0; var dc = 0
            for (y in y0 until y0 + rows) {
                val i = y * rowStride + x * pixStride
                val r = buf.get(i).toInt() and 0xFF
                val g = buf.get(i + 1).toInt() and 0xFF
                val b = buf.get(i + 2).toInt() and 0xFF
                if (r > 150 && g > 150 && b > 150 && abs(r - b) < 45) wc++
                if (r > 190 && g < 60 && b < 60) rc++
                if (r in 36..119 && g < 30 && b < 30) dc++
            }
            if (dc >= rows / 2) darkCols++
            if (wc >= maxOf(1, rows / 2)) {
                wCols++
                if (x < wMin) wMin = x
                if (x > wMax) wMax = x
            }
            if (rc >= maxOf(1, rows / 3)) {
                rCols++
                if (x < rMin) rMin = x
                if (x > rMax) rMax = x
            }
        }

        out.valid = false; out.zl = -1; out.zr = -1; out.mx = -1.0
        if (darkCols.toDouble() / width < 0.25) return   // bar not on screen
        out.valid = true
        if (wCols >= 8 && (wMax - wMin) < 0.45 * width) {
            out.zl = wMin - x0
            out.zr = wMax - x0
        }
        if (rCols >= 2) out.mx = (rMin + rMax) / 2.0 - x0
    }
}

/** Remembers the white zone + marker speed and decides when to tap. Port of the PC script's Tracker. */
class Tracker {
    companion object {
        const val LOST_GRACE = 0.4   // s the zone is remembered if the marker hides it
        const val COOLDOWN = 0.5     // s between taps
        const val MARGIN = 4.0       // px the marker must be inside the zone
        const val TOL = 9            // px zone edge jitter allowed
    }

    private var zl = -1
    private var zr = -1
    private var lastZoneT = -1e9
    private val hist = ArrayList<Pair<Double, Double>>()
    private var armed = true
    private var lastClickT = -1e9

    fun reset() {
        zl = -1; zr = -1
        hist.clear()
        armed = true
    }

    /** t in seconds, latency in seconds. Returns true when a tap should happen now. */
    fun update(t: Double, s: BarState, latency: Double): Boolean {
        if (s.zl >= 0) {
            if (zr >= 0 && abs(s.zr - zr) <= TOL) {
                zl = minOf(zl, s.zl)
                zr = s.zr
            } else {
                zl = s.zl
                zr = s.zr
                armed = true            // new/moved zone = new attempt
            }
            lastZoneT = t
        } else if (t - lastZoneT > LOST_GRACE) {
            reset()                     // bar is gone
            return false
        }

        if (zl < 0 || s.mx < 0) return false

        hist.add(Pair(t, s.mx))
        while (hist.isNotEmpty() && t - hist[0].first > 0.12) hist.removeAt(0)
        var v = 0.0
        if (hist.size >= 2 && hist.last().first > hist[0].first) {
            v = (hist.last().second - hist[0].second) / (hist.last().first - hist[0].first)
        }
        val xp = s.mx + v * latency
        val inside = xp >= zl + MARGIN && xp <= zr - MARGIN

        if (!inside && t - lastClickT > COOLDOWN) armed = true
        if (inside && armed && t - lastClickT > COOLDOWN) {
            armed = false
            lastClickT = t
            return true
        }
        return false
    }
}
