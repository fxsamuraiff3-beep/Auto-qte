package com.example.qtebot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

@Suppress("DEPRECATION")
class MainActivity : Activity() {

    private val req = 42
    private val keys = listOf("left", "right", "y", "tx", "ty")
    private val defaults = mapOf("left" to 33f, "right" to 67.2f, "y" to 81.2f, "tx" to 55f, "ty" to 30f)
    private val names = mapOf(
        "left" to "Bar LEFT end (% of screen width)",
        "right" to "Bar RIGHT end (% of screen width)",
        "y" to "Bar middle height (% of screen height)",
        "tx" to "Tap spot X (%) - an empty part of the game screen",
        "ty" to "Tap spot Y (%)"
    )
    private val fields = HashMap<String, EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
        val prefs = getSharedPreferences("qte", Context.MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun label(t: String, size: Float = 14f) = TextView(this).apply {
            text = t
            textSize = size
            setPadding(0, pad / 2, 0, 0)
        }

        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { onClick() }
        }

        col.addView(label("QTE Bot", 24f))
        col.addView(label("Do steps 1 and 2 once, then press 3 each time you want to play."))

        col.addView(button("1) Allow floating button") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        col.addView(button("2) Turn on the tap service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            toast("Find \"QTE Bot\" and switch it on")
        })

        col.addView(label("Bar position (defaults match the recording you sent):", 13f))
        for (k in keys) {
            col.addView(label(names[k]!!, 12f))
            val e = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setText(prefs.getFloat(k, defaults[k]!!).toString())
            }
            fields[k] = e
            col.addView(e)
        }

        col.addView(button("3) Start bot") {
            save()
            if (!Settings.canDrawOverlays(this)) {
                toast("Do step 1 first")
                return@button
            }
            if (TapService.instance == null) {
                toast("Do step 2 first")
                return@button
            }
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), req)
        })
        col.addView(button("Stop bot") {
            stopService(Intent(this, BotService::class.java))
        })

        col.addView(
            label(
                "After starting, open the game in landscape. The floating panel shows what the bot sees: " +
                    "when the QTE bar is on screen it should show zone/marker numbers instead of \"bar not found\". " +
                    "Press OFF to turn it ON. Use - / + to fix late or early taps.",
                12f
            )
        )

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun save() {
        val ed = getSharedPreferences("qte", Context.MODE_PRIVATE).edit()
        for (k in keys) {
            ed.putFloat(k, fields[k]!!.text.toString().toFloatOrNull() ?: defaults[k]!!)
        }
        ed.apply()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == req && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, BotService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        } else if (requestCode == req) {
            toast("Screen capture was not allowed")
        }
    }
}
