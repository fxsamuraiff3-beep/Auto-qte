package com.example.qtebot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Foreground service: captures the screen, watches the QTE bar, taps via TapService,
 * and shows a small floating panel with an ON/OFF button.
 */
class BotService : Service() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null

    private var panel: View? = null
    private var statusView: TextView? = null
    private var latView: TextView? = null
    private var onOffBtn: Button? = null

    @Volatile private var active = false
    @Volatile private var latency = 0.06   // seconds

    private var capW = 0
    private var capH = 0
    private var barL = 0
    private var barR = 0
    private var barY = 0
    private var tapX = 0f
    private var tapY = 0f

    private val tracker = Tracker()
    private val state = BarState()
    private var clicks = 0
    private var lastUi = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        val code = intent.getIntExtra("code", 0)
        val data = readData(intent)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        setupCapture(code, data)
        showPanel()
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)
        else i.getParcelableExtra<Intent>("data")

    private fun startAsForeground() {
        val channel = "qte"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(channel, "QTE Bot", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, channel)
            .setContentTitle("QTE Bot is running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    // ---------------------------------------------------------------- capture
    private fun setupCapture(code: Int, data: Intent) {
        // Always landscape-shaped: the game is played sideways.
        val b = wm.maximumWindowMetrics.bounds
        capW = maxOf(b.width(), b.height())
        capH = minOf(b.width(), b.height())

        val prefs = getSharedPreferences("qte", Context.MODE_PRIVATE)
        fun f(k: String, d: Float) = prefs.getFloat(k, d) / 100f
        barL = (capW * f("left", 33f)).toInt()
        barR = (capW * f("right", 67.2f)).toInt().coerceAtMost(capW - 1)
        barY = (capH * f("y", 81.2f)).toInt()
        tapX = capW * f("tx", 55f)
        tapY = capH * f("ty", 30f)
        latency = prefs.getInt("lat", 60) / 1000.0

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj

        val t = HandlerThread("qte-capture").also { it.start() }
        thread = t
        val h = Handler(t.looper)

        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, h)

        val r = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        reader = r
        r.setOnImageAvailableListener({ rd -> onFrame(rd) }, h)

        display = proj.createVirtualDisplay(
            "qte", capW, capH, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, h
        )
    }

    private fun onFrame(rd: ImageReader) {
        val img = rd.acquireLatestImage() ?: return
        try {
            val plane = img.planes[0]
            Detector.detect(plane.buffer, plane.rowStride, plane.pixelStride, barL, barR, barY, 6, state)

            if (active) {
                val now = System.nanoTime() / 1e9
                if (tracker.update(now, state, latency)) {
                    clicks++
                    TapService.instance?.tap(tapX, tapY)
                }
            }

            val ms = System.currentTimeMillis()
            if (ms - lastUi > 150) {
                lastUi = ms
                val s = if (!state.valid) "bar not found"
                else "zone ${state.zl}-${state.zr}  marker ${state.mx.toInt()}  taps $clicks"
                main.post { statusView?.text = s }
            }
        } finally {
            img.close()
        }
    }

    // ---------------------------------------------------------------- floating panel
    private fun showPanel() {
        val dens = resources.displayMetrics.density
        fun d(v: Int) = (v * dens).toInt()

        fun btn(label: String, w: Int, click: () -> Unit) = Button(this).apply {
            text = label
            textSize = 13f
            minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
            setPadding(d(6), d(2), d(6), d(2))
            layoutParams = LinearLayout.LayoutParams(d(w), d(36))
            setOnClickListener { click() }
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC000000.toInt())
            setPadding(d(6), d(6), d(6), d(6))
        }
        statusView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            text = "starting... (drag me)"
        }
        box.addView(statusView)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        onOffBtn = btn("OFF", 64) { toggle() }.apply {
            setBackgroundColor(0xFFBB3333.toInt()); setTextColor(Color.WHITE)
        }
        row.addView(onOffBtn)
        row.addView(btn("-", 36) { changeLatency(-10) })
        latView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(d(54), d(36))
            text = "${(latency * 1000).toInt()}ms"
        }
        row.addView(latView)
        row.addView(btn("+", 36) { changeLatency(10) })
        row.addView(btn("X", 36) { stopSelf() })
        box.addView(row)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = d(8)
            y = (capH * 0.22).toInt()
        }

        // drag the panel by its status text
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        statusView!!.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(box, lp)
                }
            }
            true
        }

        wm.addView(box, lp)
        panel = box
    }

    private fun toggle() {
        active = !active
        tracker.reset()
        onOffBtn?.apply {
            text = if (active) "ON" else "OFF"
            setBackgroundColor(if (active) 0xFF22AA22.toInt() else 0xFFBB3333.toInt())
        }
    }

    private fun changeLatency(deltaMs: Int) {
        val ms = ((latency * 1000).toInt() + deltaMs).coerceIn(0, 250)
        latency = ms / 1000.0
        latView?.text = "${ms}ms"
        getSharedPreferences("qte", Context.MODE_PRIVATE).edit().putInt("lat", ms).apply()
    }

    override fun onDestroy() {
        active = false
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        thread?.quitSafely()
        super.onDestroy()
    }
}
